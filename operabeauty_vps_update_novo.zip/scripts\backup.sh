#!/bin/bash

# OperaBeauty - Script Automatizado de Backup do Banco de Dados (FINDING-23)
# Este script deve ser chamado pelo cron diariamente

# Diretórios e Nomenclaturas
BACKUP_DIR="/backups/operabeauty"
mkdir -p "$BACKUP_DIR"

DATE=$(date +"%Y%m%d_%H%M%S")
FILENAME="operabeauty_db_$DATE.sql.gz"
ENCRYPTED_FILENAME="$FILENAME.enc"

# Credenciais e Variáveis (Recomenda-se setar no ambiente do host ou via variáveis do bash)
# A senha de cifragem deve ser forte e armazenada em um cofre de senhas!
ENCRYPTION_PASSWORD=${BACKUP_ENCRYPTION_PASSWORD:-"MudarIssoEmProducao!123"}
S3_BUCKET=${BACKUP_S3_BUCKET:-"s3://meu-bucket-de-backups-operabeauty"}

echo "[$(date)] Iniciando rotina de backup..."

# 1. Realizar o pg_dump através do container do Docker (DUMP + GZIP)
# O nome do container deve corresponder ao que está rodando ('operabeauty-db' ou 'operabeauty-api-db-1')
CONTAINER_NAME=$(docker ps --format '{{.Names}}' | grep db | head -n 1)

if [ -z "$CONTAINER_NAME" ]; then
    echo "[$(date)] ERRO: Container do banco de dados não encontrado."
    exit 1
fi

echo "[$(date)] Extraindo dump do container $CONTAINER_NAME..."
docker exec "$CONTAINER_NAME" pg_dump -U postgres operabeauty | gzip > "$BACKUP_DIR/$FILENAME"

# 2. Cifrar o backup usando OpenSSL (AES-256-CBC com PBKDF2)
echo "[$(date)] Cifrando o backup..."
openssl enc -aes-256-cbc -salt -pbkdf2 -in "$BACKUP_DIR/$FILENAME" -out "$BACKUP_DIR/$ENCRYPTED_FILENAME" -pass pass:"$ENCRYPTION_PASSWORD"

# Validação se a cifragem funcionou
if [ $? -eq 0 ]; then
    # Remove o arquivo .gz original em texto plano
    rm "$BACKUP_DIR/$FILENAME"
    echo "[$(date)] Arquivo original em texto plano removido."
else
    echo "[$(date)] ERRO ao cifrar o arquivo de backup."
    exit 1
fi

# 3. Enviar para repositório remoto (ex: AWS S3)
echo "[$(date)] Enviando para o repositório externo ($S3_BUCKET)..."
# Descomente a linha abaixo e configure o AWS CLI na VPS para que o upload ocorra de fato:
# aws s3 cp "$BACKUP_DIR/$ENCRYPTED_FILENAME" "$S3_BUCKET/"

# 4. Limpeza Local: manter apenas os backups locais dos últimos 7 dias (rotatividade)
echo "[$(date)] Limpando backups locais antigos (mais de 7 dias)..."
find "$BACKUP_DIR" -type f -name "*.enc" -mtime +7 -exec rm {} \;

echo "[$(date)] Backup finalizado com sucesso: $BACKUP_DIR/$ENCRYPTED_FILENAME"
