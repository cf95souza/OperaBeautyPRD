# Guia Passo a Passo: Configuração de Servidor VPS (VirtualBox / Ubuntu Server)

Este documento é o manual oficial de referência para preparar o servidor Linux (Ubuntu Server) do zero, gerenciar o Docker e garantir que a aplicação **OperaBeauty** (Banco de Dados PostgreSQL e API do Backend) suba de forma automática.

Ele foi desenhado especificamente para ser didático, amigável para iniciantes e detalhar o funcionamento do sistema.

---

## 🚀 Entendendo o Docker: Ele sobe sozinho?

Sim! Mas para que ele suba sozinho após a máquina virtual ser ligada ou reiniciada, duas configurações precisam estar ativas (e nós as configuramos no seu servidor):

1. **O serviço do Docker habilitado no Linux (Boot do Sistema)**:
   Isso garante que o "motor" do Docker seja iniciado assim que o Ubuntu Server ligar.
2. **A regra de reinicialização dos containers (`restart: always`)**:
   No arquivo `docker-compose.yml`, definimos que tanto o banco de dados quanto a API têm a diretiva `restart: always`. Isso significa que se o motor do Docker estiver rodando, ele iniciará automaticamente os containers associados.

Abaixo, você encontrará o guia completo de como gerenciar isso e como preparar um servidor do zero.

---

## 🛠️ PARTE 1: Preparando a Máquina Virtual (VirtualBox / Ubuntu)

Se precisar criar o ambiente do zero novamente, siga estes passos:

### 1. Criar a VM no VirtualBox
*   Baixe a ISO do **Ubuntu Server LTS** (versão recomendada: 22.04 ou 24.04).
*   Crie uma nova VM no VirtualBox com pelo menos **1 GB ou 2 GB de memória RAM** e **1 ou 2 CPUs**.
*   Durante a instalação do Ubuntu, siga o padrão de configurações e crie seu usuário (ex: `caio`).

### 2. Configurar a Placa de Rede (Crucial para o Windows enxergar a VM)
Por padrão, a VM é criada no modo "NAT", o que impede o seu Windows de enviar requisições para a VM.
1. Com a VM desligada no VirtualBox, vá em **Configurações > Rede**.
2. Mude o campo "Conectado a:" de **NAT** para **Placa em modo Bridge** (Adaptador de Ponte).
3. Selecione a placa de rede física do seu computador (Wi-Fi ou Ethernet) que está conectada à internet.
4. Ligue a VM.

### 3. Descobrir o IP da VM no Linux
Para acessar a máquina virtual pelo Windows, precisamos do IP dela na sua rede local:
1. Faça login no terminal do Ubuntu Server.
2. Digite o comando:
   ```bash
   ip a
   ```
3. Procure por uma linha que contenha algo como `inet 192.168.X.X` (geralmente abaixo de uma interface chamada `enp0s3` ou similar). Este é o IP da sua VM.
4. Abra o prompt de comando do seu Windows e teste a conexão digitando:
   ```cmd
   ping IP_DA_SUA_VM
   ```
   *(Substitua `IP_DA_SUA_VM` pelo IP obtido, ex: `ping 192.168.56.100`)*. Se houver resposta, as máquinas estão conversando!

### 4. Configurar Memória Swap (Prevenir Travamentos por OOM)
Máquinas virtuais com 1GB ou 2GB de RAM podem travar ao rodar banco de dados e API juntos. Para evitar que o sistema mate os processos por falta de memória (Out-Of-Memory):
1. Crie um arquivo de swap de 2GB e ative-o:
   ```bash
   sudo fallocate -l 2G /swapfile
   sudo chmod 600 /swapfile
   sudo mkswap /swapfile
   sudo swapon /swapfile
   ```
2. Torne-o permanente para que inicie junto com a VM:
   ```bash
   echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
   ```
3. Otimize o uso (reduza a prioridade de uso do swap):
   ```bash
   sudo sysctl vm.swappiness=10
   echo 'vm.swappiness=10' | sudo tee -a /etc/sysctl.conf
   ```

---

## 🐳 PARTE 2: Instalando o Docker no Ubuntu Server

Com a rede funcionando, instale o motor que rodará nosso banco e nossa API. Abra o terminal do Ubuntu (ou conecte via cliente SSH como PuTTY) e execute os seguintes comandos:

```bash
# 1. Atualiza a lista de pacotes disponíveis do sistema
sudo apt update && sudo apt install -y ca-certificates curl gnupg lsb-release

# 2. Cria a pasta segura para as chaves de segurança do repositório Docker
sudo mkdir -p /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg

# 3. Adiciona o repositório oficial do Docker às fontes do Ubuntu
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# 4. Atualiza novamente o gerenciador com a nova fonte adicionada e instala o Docker
sudo apt update && sudo apt install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin

# 5. Adiciona o seu usuário de sistema (ex: caio) ao grupo do Docker
# Isso evita ter que digitar "sudo" antes de qualquer comando docker
sudo usermod -aG docker $USER
```
> [!IMPORTANT]
> Após executar o último comando de adicionar o usuário ao grupo, **reinicie o servidor** (`sudo reboot`) ou faça logout e login novamente para aplicar a permissão.

---

## ⚙️ PARTE 3: Configurando o Docker para Iniciar no Boot

Para garantir que o motor do Docker ligue sozinho sempre que a VM iniciar, rode no terminal:

```bash
# Habilita o serviço do Docker para inicializar no boot
sudo systemctl enable docker

# Habilita o gerenciador de containers para inicializar no boot
sudo systemctl enable containerd
```

Pronto! Agora o servidor Linux está programado para ligar o Docker automaticamente na inicialização.

---

## 📋 PARTE 4: Gerenciando e Subindo a Aplicação (Dia a Dia)

Toda a nossa aplicação está na pasta transferida via WinSCP (ex: `/home/caio/OperaBeauty`). Para subir o banco e a API:

### 1. Entrar na pasta do projeto no Linux
```bash
cd /home/caio/OperaBeauty
```

### 2. Subir a aplicação (Banco e API)
```bash
docker compose up -d
```
*   O `-d` (modo Daemon) serve para rodar o processo em segundo plano, liberando o seu terminal do Linux.

### 3. Verificar o status dos containers
Para saber se os containers subiram corretamente e quais portas estão abertas:
```bash
docker compose ps
```

### 4. Como ver os logs da API em tempo real
Se o sistema apresentar erros ou se você quiser monitorar as requisições que chegam da sua máquina Windows:
```bash
docker compose logs -f api
```
*(Use `Ctrl + C` para sair da visualização de logs)*

### 5. Como desligar a aplicação
Caso precise parar tudo temporariamente:
```bash
docker compose down
```

---

## 📂 PARTE 5: Comandos de Monitoramento de Sistema (Cheat Sheet para Iniciantes)

Se você suspeitar que a VM está travando ou que o Docker não está rodando, use estes comandos de diagnóstico:

| Comando | O que ele faz? |
| :--- | :--- |
| `sudo systemctl status docker` | Mostra se o motor do Docker está ativo (active/running) ou parado (inactive/dead). |
| `sudo systemctl start docker` | Liga o serviço do Docker se ele estiver parado. |
| `sudo systemctl stop docker` | Desliga o serviço do Docker completamente. |
| `docker ps` | Lista os containers que estão rodando na máquina neste exato momento. |
| `docker ps -a` | Lista todos os containers instalados, inclusive os que deram erro ou estão parados. |
| `top` ou `htop` | Mostra o consumo de memória RAM e Processador do servidor Linux (aperte `q` para sair). |
| `df -h` | Mostra o espaço disponível no disco rígido da VM. |

---

## 🔄 PARTE 6: O Fluxo de Atualização (Do Windows para a VM)

Como você fará as correções na sua máquina local (Windows) e só mandará para o servidor no fim:

1. **Faça as alterações de código** nos arquivos do seu Windows.
2. **Teste localmente** no Windows apontando para o banco da VM (usando o IP na conexão do `.env`).
3. **Abra o WinSCP** no Windows e conecte na VM.
4. **Envie os arquivos modificados** da sua máquina Windows para a pasta correspondente no Linux (geralmente a pasta `/home/caio/OperaBeauty/backend`).
5. **Se alterou o backend**, conecte na VM via SSH e reinicie os containers para a API compilar o código novo:
   ```bash
   cd /home/caio/OperaBeauty
   docker compose down
   docker compose up -d --build
   ```
   *(A flag `--build` garante que o Docker refaça a imagem da API com as suas novas linhas de código)*.

---

## ⚡ PARTE 7: Solução de Problemas Rápidos (Troubleshooting)

### ❌ Erro: `connect ECONNREFUSED` ou `connect ETIMEDOUT` no IP da VM (`192.168.56.100`)

Se a conexão do seu backend no Windows com o PostgreSQL da VM parar de funcionar de um dia para o outro (mesmo com a VM ligada e o Docker rodando), é porque o Windows guardou o mapeamento IP antigo em cache (Cache ARP) ou a placa Host-Only do VirtualBox travou.

#### Como resolver imediatamente:
1. Abra o **Prompt de Comando (CMD)** do Windows **como Administrador** (clique no botão direito no CMD e escolha "Executar como Administrador").
2. Execute o comando abaixo para limpar o cache daquele IP específico:
   ```cmd
   arp -d 192.168.56.100
   ```
3. Se o IP da sua VM tiver mudado temporariamente para `.101`, limpe também:
   ```cmd
   arp -d 192.168.56.101
   ```
4. Teste a conexão novamente iniciando o backend local.

---

## 🛡️ PARTE 8: Configuração de Firewall (UFW) e Segurança Básica (FINDING-18)

Em ambiente de produção, é extremamente perigoso deixar todas as portas do servidor abertas. Vamos usar o firewall nativo do Ubuntu (`ufw`) para permitir apenas o tráfego web essencial e o acesso remoto (SSH).

### 1. Garantir que o UFW está instalado e bloquear tudo por padrão
```bash
sudo apt update && sudo apt install -y ufw
sudo ufw default deny incoming
sudo ufw default allow outgoing
```

### 2. Liberar as portas essenciais
```bash
# Permitir conexões SSH (porta 22) - CUIDADO: Se você usar uma porta SSH diferente, altere o número aqui!
sudo ufw allow 22/tcp

# Permitir tráfego HTTP e HTTPS (usados pelo Caddy ou Nginx para a aplicação web)
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
```

### 3. Ativar o Firewall
```bash
sudo ufw enable
```
*(Confirme com `y` quando o sistema avisar que isso pode interromper conexões SSH existentes. Como a porta 22 acabou de ser liberada no passo 2, a sua conexão atual não cairá).*

### 4. Verificar o Status
```bash
sudo ufw status verbose
```
Você deverá ver as portas 22, 80 e 443 listadas como `ALLOW IN`. Qualquer tentativa externa de acessar outras portas (como a 5432 do banco ou a 5000 do backend) será sumariamente bloqueada pelo Linux, oferecendo a primeira camada forte de segurança da sua infraestrutura.

---

## 💾 PARTE 9: Backup Automatizado do Banco de Dados (FINDING-23)

Para garantir que os dados dos salões nunca sejam perdidos, o projeto inclui um script de backup (`scripts/backup.sh`) que:
1. Faz o dump (`pg_dump`) do container Docker.
2. Compacta e **cifra** o arquivo com AES-256-CBC (protegendo dados sensíveis da LGPD).
3. Prepara o envio para a AWS S3.

### Como ativar o Backup Automático na VPS

1. Na sua máquina local, certifique-se de que a pasta `scripts` com o `backup.sh` foi enviada para o servidor.
2. Acesse a VPS via SSH.
3. Dê permissão de execução ao script:
   ```bash
   chmod +x /home/caio/OperaBeauty/scripts/backup.sh
   ```
4. Adicione a rotina ao Crontab do Linux para rodar todos os dias às 03:00 da manhã. Digite:
   ```bash
   crontab -e
   ```
5. Adicione a seguinte linha no final do arquivo:
   ```bash
   0 3 * * * /bin/bash /home/caio/OperaBeauty/scripts/backup.sh >> /var/log/operabeauty_backup.log 2>&1
   ```
   *(A primeira coluna `0` representa o minuto, e o `3` representa a hora - ou seja, 03:00 da manhã. Os logs de execução ficarão salvos em `/var/log/operabeauty_backup.log`)*.

---

## 🧹 PARTE 10: Limpeza e Manutenção (FINDING-09)

Para evitar que o banco de dados infle com dados inúteis (ex: tokens de acesso expirados), crie uma rotina de limpeza diária.

1. Dê permissão ao script de limpeza:
   ```bash
   chmod +x /home/caio/OperaBeauty/scripts/cleanup_tokens.sh
   ```
2. Adicione-o ao Crontab (`crontab -e`) para rodar às 04:00 da manhã:
   ```bash
   0 4 * * * /bin/bash /home/caio/OperaBeauty/scripts/cleanup_tokens.sh >> /var/log/operabeauty_cleanup.log 2>&1
   ```

---

## 🔒 PARTE 11: Hardening de SSH e Prevenção de Ataques (Fail2ban) (FINDING-30)

Sua VPS fica exposta à internet 24h por dia, atraindo robôs que tentam adivinhar senhas via SSH (ataques de força bruta). Para blindar o servidor, tome as seguintes medidas:

### 1. Desabilitar o Login por Senha (Usar Apenas Chaves)
*Antes de fazer isso, certifique-se de que você já configurou o acesso via Chave Pública (SSH Key) na sua máquina local e consegue logar na VPS sem digitar senha!*

1. Edite o arquivo de configuração do SSH:
   ```bash
   sudo nano /etc/ssh/sshd_config
   ```
2. Procure as seguintes linhas e altere-as para:
   ```text
   PasswordAuthentication no
   PermitRootLogin prohibit-password
   PubkeyAuthentication yes
   ```
3. Salve o arquivo (`Ctrl+O`, `Enter`, `Ctrl+X`) e reinicie o serviço SSH:
   ```bash
   sudo systemctl restart ssh
   ```

### 2. Instalar o Fail2ban
O Fail2ban monitora os logs do servidor e bane (via firewall) automaticamente IPs que falharem muitas tentativas de login consecutivas.

1. Instale o pacote:
   ```bash
   sudo apt update && sudo apt install fail2ban -y
   ```
2. Habilite o serviço para iniciar com o sistema:
   ```bash
   sudo systemctl enable fail2ban
   sudo systemctl start fail2ban
   ```
3. Para checar o status e ver se IPs já foram banidos no filtro do SSH:
   ```bash
   sudo fail2ban-client status sshd
   ```

---

## 💻 PARTE 12: Setup da VM de Testes (Homologação Paridade)

Para garantir que a sua **VM Local (VirtualBox)** seja um espelho perfeito da VPS de produção, criamos scripts automatizados de configuração.

### Passo 1: Executando o Setup Automático na VM

Se a sua VM já foi criada (conforme a Parte 1 deste guia) e você enviou a pasta `OperaBeauty` para ela via WinSCP, acesse-a via terminal e rode:

```bash
cd /home/caio/OperaBeauty
chmod +x scripts/setup_vm.sh
sudo bash scripts/setup_vm.sh
```

Esse script se encarregará de instalar o Docker, configurar o Swap de 2GB e blindar o Firewall UFW automaticamente.

### Passo 2: Configurando o Ambiente Local

1. Verifique se o arquivo `.env.vm` foi criado.
2. O script de deploy (`deploy_vm.sh`) automaticamente o usará se não houver um `.env` existente, garantindo a configuração para `localhost` (sem HTTPS) e senhas simuladas de banco de dados para segurança em testes locais.

### Passo 3: Deploy Automatizado e Validação

Sempre que enviar arquivos novos do Windows para a VM via WinSCP, utilize o script de deploy automatizado para recompilar a API rapidamente:

```bash
bash scripts/deploy_vm.sh
```

Para confirmar se a sua VM obedece todas as 15 exigências estruturais e de segurança da máquina de produção (VPS), rode o script de auditoria:

```bash
bash scripts/validate_parity.sh
```

*(Ele deverá listar todos os itens com "✅" em verde, confirmando o sucesso da paridade).*
