import pool from '../config/db.js';

async function seedSuperAdmins() {
  console.log('Criando Super Admins com senhas fortes...');
  const admins = [
    {
      email: 'cf95.souza@gmail.com',
      password: 'Master_Admin@2026', // Mínimo 8 caracteres, 1 maiúscula, 1 minúscula, 1 especial
      name: 'Super Admin Principal'
    },
    {
      email: 'admin2@operabeauty.com',
      password: 'Sec_Admin!2026',
      name: 'Super Admin Secundário'
    }
  ];

  try {
    for (const admin of admins) {
      // Deleta se já existir para recriar com a senha correta
      await pool.query('DELETE FROM public.cap_platform_admins WHERE email = $1', [admin.email]);
      
      const query = `
        INSERT INTO public.cap_platform_admins (email, password_hash, name)
        VALUES (
          $1,
          crypt($2, gen_salt('bf')),
          $3
        )
      `;
      await pool.query(query, [admin.email, admin.password, admin.name]);
      console.log(`✅ Super Admin criado: ${admin.email} | Senha temporária: ${admin.password}`);
    }
  } catch (err) {
    console.error('❌ Erro ao criar Super Admins:', err);
  } finally {
    await pool.end();
  }
}

seedSuperAdmins();
