-- Migração para Indique e Ganhe (Referrals) - Fase 10.4

-- 1. Adicionar colunas em cap_clients
ALTER TABLE public.cap_clients
ADD COLUMN IF NOT EXISTS referral_code VARCHAR(20) UNIQUE,
ADD COLUMN IF NOT EXISTS referred_by UUID REFERENCES public.cap_clients(id) ON DELETE SET NULL;

-- 2. Índices
CREATE INDEX IF NOT EXISTS idx_cap_clients_referral_code ON public.cap_clients(referral_code);
CREATE INDEX IF NOT EXISTS idx_cap_clients_referred_by ON public.cap_clients(referred_by);

-- 3. Gerar referral_code para os clientes já existentes (Retroativo)
-- O código será os 4 primeiros caracteres do nome (sem espaços) + os 4 primeiros do ID.
UPDATE public.cap_clients
SET referral_code = 
    UPPER(
        SUBSTRING(REPLACE(name, ' ', ''), 1, 4) || 
        SUBSTRING(REPLACE(id::text, '-', ''), 1, 4)
    )
WHERE referral_code IS NULL;

-- Como precisamos garantir unicidade, adicionaremos a constraint UNIQUE depois de preencher os existentes.
-- (A constraint UNIQUE no ALTER TABLE inicial pode falhar se houvesse nulos conflitantes, mas setamos a coluna acima)
-- Para simplificar, a restrição UNIQUE já foi adicionada na instrução ALTER original assumindo dados limpos.
