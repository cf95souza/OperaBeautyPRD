-- Migração para Self Check-in com Mimos (Fase 10.1)

-- 1. Tabela cap_tenants
ALTER TABLE public.cap_tenants 
ADD COLUMN IF NOT EXISTS waiting_menu_enabled BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS waiting_menu_items JSONB DEFAULT '["Água", "Café", "Espumante"]'::jsonb;

-- 2. Tabela cap_appointments
ALTER TABLE public.cap_appointments
ADD COLUMN IF NOT EXISTS checkin_status TEXT DEFAULT 'pending',
ADD COLUMN IF NOT EXISTS checkin_request TEXT;
