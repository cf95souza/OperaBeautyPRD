import pg from 'pg';
import dotenv from 'dotenv';

dotenv.config({ path: '../.env' }); // Carrega o env da pasta pai (backend/)

const { Pool } = pg;

const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: parseInt(process.env.DB_PORT || '5432'),
});

async function migrate() {
  console.log('🔄 Iniciando migração para a tabela de Super Admins...');
  
  try {
    // 1. Criar a tabela cap_platform_admins
    await pool.query(`
      CREATE TABLE IF NOT EXISTS public.cap_platform_admins (
          id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
          email TEXT UNIQUE NOT NULL,
          password_hash TEXT NOT NULL,
          name TEXT NOT NULL,
          created_at TIMESTAMPTZ DEFAULT NOW()
      );
    `);
    console.log('✅ Tabela cap_platform_admins criada com sucesso.');

    // 2. Inserir o Super Admin padrão cf95.souza@gmail.com com senha mudar_senha_mestre_123 hashed via pgcrypto
    await pool.query(`
      INSERT INTO public.cap_platform_admins (email, password_hash, name)
      VALUES (
          'cf95.souza@gmail.com',
          crypt('mudar_senha_mestre_123', gen_salt('bf')),
          'Super Admin'
      )
      ON CONFLICT (email) DO NOTHING;
    `);
    console.log('✅ Usuário Super Admin cf95.souza@gmail.com inserido com sucesso.');

  } catch (error) {
    console.error('❌ Erro durante a migração:', error);
  } finally {
    await pool.end();
    console.log('🔄 Conexão com o banco finalizada.');
  }
}

migrate();
