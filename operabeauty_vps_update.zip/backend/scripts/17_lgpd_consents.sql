-- Migração para Termos de Consentimento (Fase 11.6)

-- Modelos de Termos criados pelo salão (ex: Termo Botox)
CREATE TABLE IF NOT EXISTS public.cap_terms_templates (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES public.cap_tenants(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Consentimentos (Termos específicos enviados a um cliente)
CREATE TABLE IF NOT EXISTS public.cap_consents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES public.cap_tenants(id) ON DELETE CASCADE,
    client_id UUID NOT NULL REFERENCES public.cap_clients(id) ON DELETE CASCADE,
    staff_id UUID NOT NULL REFERENCES public.cap_staff(id) ON DELETE CASCADE,
    term_template_id UUID NOT NULL REFERENCES public.cap_terms_templates(id) ON DELETE CASCADE,
    content_snapshot TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'signed')),
    signed_at TIMESTAMP WITH TIME ZONE,
    client_ip VARCHAR(50),
    user_agent TEXT,
    digital_hash VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_cap_consents_tenant_client ON public.cap_consents(tenant_id, client_id);
CREATE INDEX IF NOT EXISTS idx_cap_terms_tenant ON public.cap_terms_templates(tenant_id);
