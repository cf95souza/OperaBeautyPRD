-- Migração para Avaliações de Salão (Fase 11.3)

CREATE TABLE IF NOT EXISTS public.cap_reviews (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES public.cap_tenants(id) ON DELETE CASCADE,
    appointment_id UUID NOT NULL REFERENCES public.cap_appointments(id) ON DELETE CASCADE,
    client_id UUID NOT NULL REFERENCES public.cap_clients(id) ON DELETE CASCADE,
    professional_id UUID NOT NULL REFERENCES public.cap_staff(id) ON DELETE CASCADE,
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    -- Garante que um agendamento seja avaliado apenas 1 vez
    CONSTRAINT unique_appointment_review UNIQUE (appointment_id)
);

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_cap_reviews_tenant_id ON public.cap_reviews(tenant_id);
CREATE INDEX IF NOT EXISTS idx_cap_reviews_professional_id ON public.cap_reviews(professional_id);
CREATE INDEX IF NOT EXISTS idx_cap_reviews_client_id ON public.cap_reviews(client_id);
