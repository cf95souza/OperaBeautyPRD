import fs from 'fs';
import path from 'path';
import pool from '../config/db.js';

async function main() {
  const migrationPath = path.resolve('..', 'migrations', 'add_location_and_socials_to_tenant.sql');
  console.log(`Lendo arquivo de migração em: ${migrationPath}`);
  
  try {
    const sql = fs.readFileSync(migrationPath, 'utf8');
    console.log('Executando query no banco de dados...');
    await pool.query(sql);
    console.log('✅ Migração executada com sucesso!');
  } catch (error) {
    console.error('❌ Erro ao aplicar migração:', error);
  } finally {
    await pool.end();
  }
}

main();
