import fs from 'fs';
import path from 'path';
import pool from '../config/db.js';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function main() {
  const mdPath = path.resolve(__dirname, '..', '..', 'database.md');
  console.log(`Lendo ${mdPath}...`);
  try {
    const mdContent = fs.readFileSync(mdPath, 'utf8');
    const sqlBlocks = [];
    const regex = /```sql\n([\s\S]*?)```/g;
    let match;
    while ((match = regex.exec(mdContent)) !== null) {
      sqlBlocks.push(match[1]);
    }
    const fullSql = `
      DROP TABLE IF EXISTS public.cap_push_subscriptions CASCADE;
      DROP TABLE IF EXISTS public.cap_notifications CASCADE;
      DROP TABLE IF EXISTS public.cap_audit_logs CASCADE;
      DROP TABLE IF EXISTS public.cap_refresh_tokens CASCADE;
      DROP TABLE IF EXISTS public.cap_leads CASCADE;
      DROP TABLE IF EXISTS public.cap_timeline_notes CASCADE;
      DROP TABLE IF EXISTS public.cap_appointments CASCADE;
      DROP TABLE IF EXISTS public.cap_service_inventory CASCADE;
      DROP TABLE IF EXISTS public.cap_inventory CASCADE;
      DROP TABLE IF EXISTS public.cap_services CASCADE;
      DROP TABLE IF EXISTS public.cap_clients CASCADE;
      DROP TABLE IF EXISTS public.cap_staff CASCADE;
      DROP TABLE IF EXISTS public.cap_profiles CASCADE;
      DROP TABLE IF EXISTS public.cap_business_hours CASCADE;
      DROP TABLE IF EXISTS public.cap_date_exceptions CASCADE;
      DROP TABLE IF EXISTS public.cap_blocked_dates CASCADE;
      DROP TABLE IF EXISTS public.cap_vouchers CASCADE;
      DROP TABLE IF EXISTS public.cap_settings CASCADE;
      DROP TABLE IF EXISTS public.cap_coupons CASCADE;
      DROP TABLE IF EXISTS public.cap_invoices CASCADE;
      DROP TABLE IF EXISTS public.cap_platform_admins CASCADE;
      DROP TABLE IF EXISTS public.cap_plans CASCADE;
      DROP TABLE IF EXISTS public.cap_platform_settings CASCADE;
      DROP TABLE IF EXISTS public.cap_tenants CASCADE;

      DROP FUNCTION IF EXISTS public.cap_register_client CASCADE;
      DROP FUNCTION IF EXISTS public.cap_login_client CASCADE;
      DROP FUNCTION IF EXISTS public.cap_login_staff CASCADE;
      DROP FUNCTION IF EXISTS public.cap_register_staff CASCADE;
      DROP FUNCTION IF EXISTS public.cap_update_staff CASCADE;
      DROP FUNCTION IF EXISTS public.cap_update_client_password CASCADE;
    ` + sqlBlocks.join('\n\n');
    console.log('Executando queries no banco de dados...');
    await pool.query(fullSql);
    console.log('✅ Banco sincronizado com sucesso com database.md!');
  } catch (err) {
    console.error('❌ Erro ao aplicar SQL:', err);
  } finally {
    await pool.end();
  }
}

main();
