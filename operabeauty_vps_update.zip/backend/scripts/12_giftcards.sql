-- Migração para Gift Cards (Vales-Presente) - Fase 10.3

CREATE TABLE IF NOT EXISTS public.cap_giftcards (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.cap_tenants(id) ON DELETE CASCADE,
    purchaser_id UUID REFERENCES public.cap_clients(id) ON DELETE SET NULL,
    service_id UUID REFERENCES public.cap_services(id) ON DELETE CASCADE,
    recipient_name TEXT,
    code VARCHAR(20) UNIQUE NOT NULL,
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'redeemed', 'expired')),
    expires_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Índices
CREATE INDEX IF NOT EXISTS idx_cap_giftcards_tenant ON public.cap_giftcards(tenant_id);
CREATE INDEX IF NOT EXISTS idx_cap_giftcards_code ON public.cap_giftcards(code);
