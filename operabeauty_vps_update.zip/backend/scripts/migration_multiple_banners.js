import pg from 'pg';
import dotenv from 'dotenv';
import path from 'path';

// Carregar variáveis de ambiente do diretório local
dotenv.config({ path: path.resolve(process.cwd(), '.env') });

const { Pool } = pg;
const pool = new Pool({
  user: process.env.DB_USER || 'postgres',
  host: process.env.DB_HOST || '192.168.56.100',
  database: process.env.DB_NAME || 'operabeauty',
  password: process.env.DB_PASSWORD || 'postgres',
  port: parseInt(process.env.DB_PORT || '5432', 10),
});

async function runMigration() {
  try {
    console.log("Iniciando migração para múltiplos banners...");
    
    // 1. Adicionar max_banners na tabela cap_plans
    console.log("Adicionando coluna max_banners à tabela cap_plans...");
    await pool.query(`
      ALTER TABLE public.cap_plans 
      ADD COLUMN IF NOT EXISTS max_banners INT DEFAULT 1;
    `);

    // 2. Adicionar plan_id na tabela cap_tenants
    console.log("Adicionando coluna plan_id à tabela cap_tenants...");
    await pool.query(`
      ALTER TABLE public.cap_tenants 
      ADD COLUMN IF NOT EXISTS plan_id UUID REFERENCES public.cap_plans(id) ON DELETE SET NULL;
    `);

    // 3. Adicionar banners na tabela cap_tenants
    console.log("Adicionando coluna banners à tabela cap_tenants...");
    await pool.query(`
      ALTER TABLE public.cap_tenants 
      ADD COLUMN IF NOT EXISTS banners JSONB DEFAULT '[]'::jsonb;
    `);

    // 4. Associar os tenants atuais ao plano padrão se não possuírem plan_id
    console.log("Vinculando tenants existentes ao plano básico...");
    await pool.query(`
      DO $$
      DECLARE
          v_default_plan_id UUID;
      BEGIN
          SELECT id INTO v_default_plan_id FROM public.cap_plans ORDER BY price ASC LIMIT 1;
          IF v_default_plan_id IS NOT NULL THEN
              UPDATE public.cap_tenants SET plan_id = v_default_plan_id WHERE plan_id IS NULL;
          END IF;
      END $$;
    `);

    // 5. Migrar dados de banner individuais atuais para o novo formato JSONB
    console.log("Migrando dados de banner atuais para o formato JSONB...");
    await pool.query(`
      UPDATE public.cap_tenants 
      SET banners = jsonb_build_array(
          jsonb_build_object(
              'id', gen_random_uuid(),
              'url', COALESCE(banner_url, ''),
              'title', COALESCE(banner_title, 'Promoção Especial'),
              'subtitle', COALESCE(banner_subtitle, 'Aproveite nossos serviços com condições especiais.')
          )
      )
      WHERE (banners IS NULL OR jsonb_array_length(banners) = 0) 
        AND (
          (banner_url IS NOT NULL AND banner_url != '') OR 
          (banner_title IS NOT NULL AND banner_title != '') OR 
          (banner_subtitle IS NOT NULL AND banner_subtitle != '')
        );
    `);

    console.log("Migração de múltiplos banners concluída com sucesso!");
  } catch (err) {
    console.error("Erro ao rodar migração:", err.message);
  } finally {
    pool.end();
  }
}

runMigration();
