import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import pool from '../config/db.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function main() {
  const migrationPath = path.join(__dirname, '12_giftcards.sql');
  console.log(`Lendo arquivo de migração em: ${migrationPath}`);
  
  try {
    const sql = fs.readFileSync(migrationPath, 'utf8');
    console.log('Executando query no banco de dados...');
    await pool.query(sql);
    console.log('✅ Migração executada com sucesso!');
  } catch (error) {
    console.error('❌ Erro ao aplicar migração:', error);
  } finally {
    await pool.end();
  }
}

main();
