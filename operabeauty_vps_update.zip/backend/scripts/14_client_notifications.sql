-- Migração para Notificações de Clientes - Fase 11.2

-- 1. Alterar cap_notifications
ALTER TABLE public.cap_notifications
ADD COLUMN IF NOT EXISTS client_id UUID REFERENCES public.cap_clients(id) ON DELETE CASCADE,
ALTER COLUMN staff_id DROP NOT NULL;

-- Para garantir integridade, a notificação deve ser para staff_id ou client_id, não ambos ou nenhum (opcional, mas bom ter, pulei CHECK por simplicidade MVP)

-- 2. Alterar cap_push_subscriptions
ALTER TABLE public.cap_push_subscriptions
ADD COLUMN IF NOT EXISTS client_id UUID REFERENCES public.cap_clients(id) ON DELETE CASCADE,
ALTER COLUMN staff_id DROP NOT NULL;

-- Se havia restrições únicas baseadas só em staff_id, nós temos que garantir endpoint unique
-- A restrição UNIQUE (endpoint) já garante unicidade.

-- 3. Índices para performance
CREATE INDEX IF NOT EXISTS idx_cap_notifications_client_id ON public.cap_notifications(client_id);
CREATE INDEX IF NOT EXISTS idx_cap_push_subscriptions_client_id ON public.cap_push_subscriptions(client_id);
