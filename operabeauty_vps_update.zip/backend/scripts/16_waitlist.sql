-- Migração para Lista de Espera (Fase 11.4)

CREATE TABLE IF NOT EXISTS public.cap_waitlist (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES public.cap_tenants(id) ON DELETE CASCADE,
    client_id UUID NOT NULL REFERENCES public.cap_clients(id) ON DELETE CASCADE,
    service_id UUID REFERENCES public.cap_services(id) ON DELETE CASCADE,
    professional_id UUID REFERENCES public.cap_staff(id) ON DELETE CASCADE,
    desired_date DATE NOT NULL,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'fulfilled', 'cancelled')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_cap_waitlist_tenant_id ON public.cap_waitlist(tenant_id);
CREATE INDEX IF NOT EXISTS idx_cap_waitlist_desired_date ON public.cap_waitlist(desired_date);
