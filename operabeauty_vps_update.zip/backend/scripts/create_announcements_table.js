import pool from '../config/db.js';

async function main() {
  try {
    console.log('Criando tabela cap_platform_announcements...');
    await pool.query(`
      CREATE TABLE IF NOT EXISTS public.cap_platform_announcements (
          id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
          title TEXT NOT NULL,
          content TEXT NOT NULL,
          type TEXT DEFAULT 'info',
          is_active BOOLEAN DEFAULT TRUE,
          created_at TIMESTAMPTZ DEFAULT NOW(),
          expires_at TIMESTAMPTZ
      );
    `);
    console.log('Tabela criada com sucesso.');
  } catch (error) {
    console.error('Erro ao criar tabela:', error);
  } finally {
    pool.end();
  }
}

main();
