import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
dotenv.config({ path: path.join(__dirname, '..', '.env') });

import pool from '../config/db.js';

async function main() {
  try {
    await pool.query(`
      INSERT INTO public.cap_audit_logs (user_role, action, entity_name, ip_address) 
      VALUES 
      ('superadmin', 'LOGIN', 'auth', '192.168.1.10'), 
      ('superadmin', 'CREATE_PLAN', 'cap_plans', '192.168.1.10')
    `);
    console.log('✅ Mock logs inseridos com sucesso!');
  } catch (error) {
    console.error('❌ Erro:', error);
  } finally {
    await pool.end();
  }
}
main();
