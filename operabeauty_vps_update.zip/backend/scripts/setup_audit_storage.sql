-- Criar tabela de Auditoria (caso não exista)
CREATE TABLE IF NOT EXISTS public.cap_audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID REFERENCES public.cap_tenants(id) ON DELETE CASCADE,
    user_id UUID,
    user_role TEXT,
    action TEXT NOT NULL,
    entity_name TEXT NOT NULL,
    entity_id UUID,
    old_data JSONB,
    new_data JSONB,
    ip_address TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Garantir que a coluna ip_address existe na tabela caso ela já tenha sido criada antes
ALTER TABLE public.cap_audit_logs ADD COLUMN IF NOT EXISTS ip_address TEXT;

-- Índices para otimizar busca de logs
CREATE INDEX IF NOT EXISTS idx_audit_tenant ON public.cap_audit_logs(tenant_id);
CREATE INDEX IF NOT EXISTS idx_audit_role ON public.cap_audit_logs(user_role);
CREATE INDEX IF NOT EXISTS idx_audit_created_at ON public.cap_audit_logs(created_at);

-- Criar tabela de imagens do CRM
CREATE TABLE IF NOT EXISTS public.cap_crm_images (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id UUID NOT NULL REFERENCES public.cap_tenants(id) ON DELETE CASCADE,
    client_id UUID NOT NULL REFERENCES public.cap_clients(id) ON DELETE CASCADE,
    image_url TEXT NOT NULL,
    size_bytes BIGINT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Índice para facilitar o agrupamento por tenant
CREATE INDEX IF NOT EXISTS idx_crm_images_tenant ON public.cap_crm_images(tenant_id);

-- Desabilitar RLS para desenvolvimento local nessas tabelas
ALTER TABLE public.cap_audit_logs DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.cap_crm_images DISABLE ROW LEVEL SECURITY;

-- MOCK DATA: Para testar a visualização de consumo de armazenamento
DO $$
DECLARE
    t_id UUID;
    c_id UUID;
BEGIN
    SELECT t.id INTO t_id FROM public.cap_tenants t LIMIT 1;
    IF FOUND THEN
        SELECT id INTO c_id FROM public.cap_clients WHERE tenant_id = t_id LIMIT 1;
        IF c_id IS NOT NULL THEN
            INSERT INTO public.cap_crm_images (tenant_id, client_id, image_url, size_bytes)
            VALUES 
            (t_id, c_id, 'https://example.com/fake-image-1.jpg', 5242880),
            (t_id, c_id, 'https://example.com/fake-image-2.jpg', 6300120),
            (t_id, c_id, 'https://example.com/fake-image-3.jpg', 3145728);
        END IF;
    END IF;
END $$;
