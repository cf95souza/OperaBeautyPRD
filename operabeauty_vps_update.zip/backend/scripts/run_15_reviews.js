import dotenv from 'dotenv';
dotenv.config({ path: '../.env' });
import pool from '../config/db.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function runMigration() {
  const sqlFilePath = path.join(__dirname, '15_reviews.sql');
  const sql = fs.readFileSync(sqlFilePath, 'utf8');

  try {
    console.log('Iniciando migração 15_reviews.sql...');
    await pool.query(sql);
    console.log('Migração concluída com sucesso!');
  } catch (error) {
    console.error('Erro na migração:', error);
  } finally {
    pool.end();
  }
}

runMigration();
