import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTenant } from '../context/TenantContext';
import { api } from '../lib/api';
import { useNotification } from '../context/NotificationProvider';
import { format, differenceInYears } from 'date-fns';
import { ptBR } from 'date-fns/locale';

const FichaClienteCRM = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { showSuccess, showError } = useNotification();
  const { tenant, session } = useTenant();

  const [client, setClient] = useState(null);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({ visits: 0, ltv: 0, favoriteServices: [], nextAppt: null });
  const [notes, setNotes] = useState([]);
  const [newNote, setNewNote] = useState('');
  const [newImage, setNewImage] = useState(null);
  const [savingNote, setSavingNote] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  useEffect(() => {
    if (!tenant || !id) return;
    fetchClientData();
  }, [tenant, id]);

  const handleUpdateVipTier = async (newTier) => {
    try {
      const updated = await api.clients.update(id, { vip_tier: newTier });
      setClient(prev => ({ ...prev, vip_tier: updated.vip_tier }));
      showSuccess(`Categoria VIP atualizada para ${newTier}!`);
    } catch (err) {
      console.error(err);
      showError("Erro ao atualizar categoria VIP.");
    }
  };

  const getVipBadge = (tier) => {
    const styles = {
      Prata: 'bg-slate-100 text-slate-700 border border-slate-200/80 shadow-[0_2px_4px_rgba(148,163,184,0.06)]',
      Ouro: 'bg-[#FFFBEB] text-[#B45309] border border-[#FDE68A]/60 shadow-[0_2px_4px_rgba(180,83,9,0.04)]',
      VIP: 'bg-[#FAF5FF] text-[#6B21A8] border border-[#E9D5FF]/60 shadow-[0_2px_4px_rgba(107,33,168,0.04)]',
      Black: 'bg-neutral-900 text-amber-200 border border-neutral-800 shadow-[0_2px_6px_rgba(0,0,0,0.12)] font-bold'
    };
    
    const label = tier || 'Prata';
    const styleClass = styles[label] || styles.Prata;
    
    return (
      <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-[10px] font-semibold uppercase tracking-wider transition-all duration-300 ${styleClass}`}>
        <span className="material-symbols-outlined text-[13px] filled" style={{ fontVariationSettings: "'FILL' 1" }}>stars</span>
        {label}
      </span>
    );
  };

  const fetchClientData = async () => {
    try {
      // 1. Fetch Client info + appointments via API
      const clientData = await api.clients.get(id);
      const apptsData = await api.appointments.list({ client_id: id });
      
      const cData = {
        ...clientData,
        cap_appointments: apptsData
      };

      setClient(cData);

      // 2. Calculate Stats
      if (cData && cData.cap_appointments) {
        const appts = cData.cap_appointments;
        const completed = appts.filter(a => a.status === 'completed');
        const ltv = completed.reduce((sum, a) => sum + Number(a.total_price), 0);
        
        // Favorite Services Ranking
        const srvCounts = {};
        completed.forEach(a => {
          const srvName = a.service_name || 'Serviço';
          srvCounts[srvName] = (srvCounts[srvName] || 0) + 1;
        });
        const sortedServices = Object.keys(srvCounts)
          .map(k => ({ name: k, count: srvCounts[k] }))
          .sort((a, b) => b.count - a.count);
        const top3 = sortedServices.slice(0, 3);

        // Next Appt
        const now = new Date();
        const future = appts
           .filter(a => new Date(a.start_time) > now && a.status === 'scheduled')
           .sort((a,b) => new Date(a.start_time) - new Date(b.start_time));

        setStats({
          visits: completed.length,
          ltv,
          favoriteServices: top3,
          nextAppt: future.length > 0 ? future[0] : null
        });
      }

      // 3. Fetch Timeline Notes via API
      try {
        const nData = await api.clients.getTimeline(id);
        if (nData) {
          setNotes(nData);
        }
      } catch (nErr) {
        console.error("Erro ao carregar notas:", nErr);
      }

    } catch (err) {
      console.error(err);
    }
    setLoading(false);
  };

  const handleAddNote = async () => {
    if (!newNote.trim() && !newImage) return;
    setSavingNote(true);
    try {
       const fd = new FormData();
       if (newNote.trim()) fd.append('content', newNote);
       if (newImage) fd.append('image', newImage);
       await api.clients.addTimelineNote(client.id, fd);
       setNewNote('');
       setNewImage(null);
       fetchClientData(); // reload notes
    } catch (err) {
       console.error(err);
       showError("Erro ao salvar anotação.");
    }
    setSavingNote(false);
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center"><span className="material-symbols-outlined animate-spin text-primary text-4xl">progress_activity</span></div>;
  if (!client) return <div className="p-10 text-center">Cliente não encontrado.</div>;

  const parseLocalBirthDate = (dateStr) => {
    if (!dateStr) return null;
    const [year, month, day] = String(dateStr).split('T')[0].split('-');
    return new Date(year, month - 1, day);
  };
  const localBirthDate = parseLocalBirthDate(client.birth_date);
  const age = localBirthDate ? differenceInYears(new Date(), localBirthDate) : null;

  return (
    <div className="flex flex-col gap-lg animate-fade-in-up w-full">
      
      {/* Header com botão de voltar */}
      <div className="flex items-center gap-4 mb-xl">
        <button 
          onClick={() => navigate(-1)}
          className="p-2 rounded-full hover:bg-surface-variant text-on-surface transition-colors flex items-center justify-center"
        >
          <span className="material-symbols-outlined">arrow_back</span>
        </button>
        <div>
          <h1 className="font-headline-md text-headline-md text-primary">Ficha do Cliente</h1>
          <p className="font-body-md text-body-md text-secondary">Detalhes e histórico do cliente</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-lg">
        
        {/* Left Column: Client Profile Card */}
        <div className="lg:col-span-1 flex flex-col gap-lg">
          
          {/* Client Info Bento */}
          <div className="bg-surface-container-lowest border border-outline-variant/30 rounded-2xl shadow-sm p-lg flex flex-col items-center text-center relative overflow-hidden">
            <div className="w-24 h-24 rounded-full overflow-hidden mb-4 bg-primary-container text-primary font-headline-lg flex items-center justify-center uppercase shadow-inner">
              {client.name.charAt(0)}
            </div>
            <h2 className="font-headline-md text-headline-md text-on-surface mb-1">{client.name}</h2>
            
            {/* VIP Tier Badge & Custom Selector */}
            <div className="flex flex-col items-center gap-2 mt-1 mb-3 relative">
              {getVipBadge(client.vip_tier)}
              
              {(session?.role === 'manager' || session?.role === 'professional') && (
                <div className="relative">
                  <button
                    onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                    className="flex items-center gap-1 text-[11px] font-semibold text-secondary hover:text-primary bg-surface-container-low hover:bg-surface-variant border border-outline-variant/60 rounded-full px-3 py-1 transition-all outline-none"
                  >
                    <span>Classificar</span>
                    <span className="material-symbols-outlined text-[14px]">expand_more</span>
                  </button>
                  
                  {isDropdownOpen && (
                    <>
                      <div className="fixed inset-0 z-10" onClick={() => setIsDropdownOpen(false)}></div>
                      
                      <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1 w-32 bg-surface border border-outline-variant/40 rounded-xl shadow-lg py-1 z-20 animate-fade-in origin-top">
                        {['Prata', 'Ouro', 'VIP', 'Black'].map((tier) => (
                          <button
                            key={tier}
                            onClick={() => {
                              handleUpdateVipTier(tier);
                              setIsDropdownOpen(false);
                            }}
                            className={`w-full text-left px-3 py-2 text-xs font-semibold hover:bg-surface-variant flex items-center justify-between transition-colors ${
                              (client.vip_tier || 'Prata') === tier ? 'text-primary bg-primary/5' : 'text-on-surface-variant'
                            }`}
                          >
                            <span>{tier}</span>
                            {(client.vip_tier || 'Prata') === tier && (
                              <span className="material-symbols-outlined text-[14px] text-primary">check</span>
                            )}
                          </button>
                        ))}
                      </div>
                    </>
                  )}
                </div>
              )}
            </div>
            
            <div className="flex items-center gap-2 mb-1">
              <p className="font-body-md text-body-md text-secondary flex items-center gap-1">
                <span className="material-symbols-outlined text-[16px]">phone_iphone</span> {client.phone}
              </p>
              <a 
                href={`https://wa.me/${client.phone.replace(/\D/g, '').startsWith('55') ? client.phone.replace(/\D/g, '') : '55' + client.phone.replace(/\D/g, '')}`}
                target="_blank"
                rel="noreferrer"
                title="Conversar no WhatsApp"
                className="w-7 h-7 rounded-full bg-[#25D366]/10 text-[#25D366] flex items-center justify-center hover:bg-[#25D366]/20 transition-colors"
              >
                <span className="material-symbols-outlined text-[14px]">forum</span>
              </a>
            </div>
            
            <p className="font-body-sm text-body-sm text-secondary flex items-center gap-1 mb-4">
              <span className="material-symbols-outlined text-[16px]">cake</span> 
              {localBirthDate ? `${format(localBirthDate, "dd 'de' MMM, yyyy", { locale: ptBR })} (${age} anos)` : 'Data de nasc. não informada'}
            </p>
            
            <div className="w-full grid grid-cols-2 gap-3 mt-2">
              <div className="bg-surface-container-low p-3 rounded-xl flex flex-col items-center border border-outline-variant/50">
                <span className="font-label-sm text-label-sm text-secondary uppercase tracking-wider mb-1">Visitas</span>
                <span className="font-headline-md text-headline-md text-primary">{stats.visits}</span>
              </div>
              <div className="bg-surface-container-low p-3 rounded-xl flex flex-col items-center border border-outline-variant/50">
                <span className="font-label-sm text-label-sm text-secondary uppercase tracking-wider mb-1">Total Gasto</span>
                <span className="font-headline-sm text-headline-sm text-primary font-bold mt-1">R$ {stats.ltv.toFixed(2).replace('.',',')}</span>
              </div>
            </div>
            <div className="w-full mt-3 bg-surface-container-low p-3 rounded-xl flex flex-col border border-outline-variant/50">
                <span className="font-label-sm text-label-sm text-secondary uppercase tracking-wider mb-2 text-center w-full block">Top 3 Serviços (Ranking)</span>
                <div className="flex flex-col gap-1 w-full">
                  {stats.favoriteServices && stats.favoriteServices.length > 0 ? (
                    stats.favoriteServices.map((srv, index) => (
                      <div key={index} className="flex items-center justify-between bg-white border border-outline-variant/30 rounded-lg p-2 shadow-sm">
                        <span className="font-label-sm text-on-surface flex items-center gap-2">
                           <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${index === 0 ? 'bg-amber-100 text-amber-700' : index === 1 ? 'bg-slate-100 text-slate-700' : 'bg-[#FFF2EB] text-[#B45309]'}`}>{index + 1}º</span>
                           <span className="truncate max-w-[120px]" title={srv.name}>{srv.name}</span>
                        </span>
                        <span className="font-label-sm text-secondary bg-surface-variant/40 px-2 rounded-md">{srv.count}x</span>
                      </div>
                    ))
                  ) : (
                    <span className="font-label-md text-label-md text-secondary text-center py-2">Nenhum serviço</span>
                  )}
                </div>
            </div>
          </div>

          {/* Next Service Card */}
          {stats.nextAppt && (
            <div className="bg-primary/5 rounded-xl border border-primary/20 p-md flex flex-col gap-3">
              <h3 className="font-label-md text-label-md text-primary uppercase tracking-wider flex items-center gap-2">
                <span className="material-symbols-outlined text-[18px]">event</span> Próximo Agendamento
              </h3>
              <div className="bg-white rounded-lg p-3 flex justify-between items-center shadow-sm">
                <div>
                  <h4 className="font-label-md text-label-md text-on-surface">{stats.nextAppt.cap_services?.name}</h4>
                  <p className="font-label-sm text-label-sm text-secondary">
                    {format(new Date(stats.nextAppt.start_time), "dd/MM, HH:mm")}
                  </p>
                </div>
                <span className="bg-primary-container text-on-primary-container font-label-sm text-label-sm px-2 py-1 rounded-full">Confirmado</span>
              </div>
            </div>
          )}
          
        </div>

        {/* Right Column: CRM Timeline */}
        <div className="lg:col-span-2 flex flex-col gap-lg">
          <div className="bg-surface-container-lowest border border-outline-variant/30 rounded-2xl shadow-sm p-lg flex flex-col h-full">
            <h3 className="font-headline-md text-headline-md text-on-surface mb-6 flex items-center gap-2">
              <span className="material-symbols-outlined text-primary">history_edu</span> CRM da Equipe (Linha do Tempo)
            </h3>
            
            {/* Add Note Area */}
            <div className="mb-8 bg-white p-5 rounded-2xl relative border border-surface-variant/40 shadow-[0px_4px_20px_rgba(0,0,0,0.03)]">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex items-center gap-2.5 sm:block">
                  <div className="w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center shrink-0 uppercase font-bold text-sm shadow-sm">
                    {session?.name ? session.name.charAt(0) : 'S'}
                  </div>
                  <span className="font-bold text-sm text-on-surface sm:hidden">
                    {session?.name || 'Profissional'}
                  </span>
                </div>
                <div className="w-full flex flex-col gap-3">
                  <textarea 
                    className="w-full bg-surface-variant/10 border border-outline-variant/60 focus:border-primary focus:ring-2 focus:ring-primary/20 rounded-xl p-3.5 font-body-md text-body-md text-on-surface placeholder:text-secondary/70 resize-none outline-none transition-all" 
                    placeholder="Adicionar nova observação sobre preferências, misturas, alertas..." 
                    rows="3"
                    value={newNote}
                    onChange={(e) => setNewNote(e.target.value)}
                  ></textarea>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
                    <div className="flex items-center gap-2">
                      <label className="cursor-pointer bg-surface-variant/30 hover:bg-surface-variant/50 text-on-surface px-4 py-2.5 rounded-xl flex items-center justify-center sm:justify-start gap-2 transition-all border border-outline-variant/40 font-semibold text-sm w-full sm:w-auto shadow-2xs">
                        <span className="material-symbols-outlined text-[20px] text-primary">add_photo_alternate</span>
                        <span className="truncate max-w-[180px]">{newImage ? newImage.name : 'Anexar Imagem'}</span>
                        <input 
                          type="file" 
                          accept="image/*"
                          className="hidden" 
                          onChange={(e) => setNewImage(e.target.files[0])}
                        />
                      </label>
                      {newImage && (
                        <button 
                          onClick={() => setNewImage(null)} 
                          title="Remover anexo"
                          className="w-10 h-10 rounded-xl bg-error/10 text-error hover:bg-error hover:text-white flex items-center justify-center transition-colors shrink-0"
                        >
                           <span className="material-symbols-outlined text-[18px]">delete</span>
                        </button>
                      )}
                    </div>
                    <button 
                      onClick={handleAddNote}
                      disabled={savingNote || (!newNote.trim() && !newImage)}
                      className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm px-6 py-2.5 rounded-xl transition-all shadow-md hover:shadow-lg disabled:opacity-40 disabled:shadow-none flex items-center justify-center gap-2 w-full sm:w-auto cursor-pointer"
                    >
                      <span className="material-symbols-outlined text-[18px]">send</span>
                      <span>{savingNote ? 'Salvando...' : 'Salvar Observação'}</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Timeline Comments */}
            <div className="flex flex-col gap-6 relative">
              {/* Connecting Line */}
              <div className="absolute left-[19px] top-4 bottom-4 w-px bg-surface-variant z-0 hidden sm:block"></div>
              
              {notes.length === 0 ? (
                 <div className="text-center py-8 text-secondary">Nenhuma observação registrada ainda.</div>
              ) : (
                notes.map((note) => (
                  <div key={note.id} className="flex gap-4 relative z-10 group">
                    <div className="w-10 h-10 rounded-full bg-surface-container-high text-on-surface flex items-center justify-center shrink-0 shadow-sm border border-surface-variant uppercase font-bold text-sm z-10">
                       {note.cap_staff?.name ? note.cap_staff.name.charAt(0) : 'P'}
                    </div>
                    <div className="bg-white border border-outline-variant/30 rounded-xl rounded-tl-sm p-4 shadow-sm w-full group-hover:shadow-md transition-shadow">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <span className="font-label-md text-label-md text-on-surface">{note.cap_staff?.name || 'Profissional'}</span>
                          <span className="font-label-sm text-label-sm text-secondary ml-2">
                             {format(new Date(note.created_at), "dd 'de' MMM, yyyy 'às' HH:mm", { locale: ptBR })}
                          </span>
                        </div>
                      </div>
                      <p className="font-body-md text-body-md text-on-surface-variant whitespace-pre-wrap">
                        {note.content}
                      </p>
                      {note.image_path && (
                        <div className="mt-3 rounded-lg overflow-hidden border border-outline-variant/30">
                          <img src={`http://localhost:5000${note.image_path}`} alt="Anexo da nota" className="max-w-full h-auto max-h-64 object-contain" />
                        </div>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FichaClienteCRM;
